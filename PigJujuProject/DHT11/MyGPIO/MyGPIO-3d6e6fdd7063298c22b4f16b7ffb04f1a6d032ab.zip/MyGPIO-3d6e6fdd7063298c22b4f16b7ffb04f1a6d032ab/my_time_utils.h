#ifndef MY_TIME_UTILS_H
#define MY_TIME_UTILS_H

void sleep_ns(int nanosec);
void sleep_us(int microsec);
void sleep_ms(int millisec);

#endif